﻿class SmartSampler {
  constructor(config = {}) {
    this.stratifiedEnabled = config.stratified ?? true;
    this.confidenceLevel = config.confidenceLevel || 0.95;
    this.samplingRates = { 
      high: config.samplingRates?.high || 0.30, 
      medium: config.samplingRates?.medium || 0.10, 
      low: config.samplingRates?.low || 0.03 
    };
    this.thresholds = { 
      highRisk: { trustScoreMin: 0.90, trustScoreMax: 0.92, operationalDaysMax: 180 }, 
      mediumRisk: { trustScoreMin: 0.92, trustScoreMax: 0.95, operationalDaysMin: 180 }, 
      lowRisk: { trustScoreMin: 0.95, operationalDaysMin: 180, recentAnomaliesMax: 0 } 
    };
  }
  selectSamples(decisions, context) { 
    if (this.stratifiedEnabled) { 
      return this.stratifiedSample(decisions, context); 
    } 
    return this.simpleSample(decisions, context); 
  }
  stratifiedSample(decisions, context) { 
    const autoApproved = decisions.filter(d => d.decision === 'AUTO_APPROVED'); 
    const strata = { 
      high: autoApproved.filter(d => this.isHighRisk(d, context)), 
      medium: autoApproved.filter(d => this.isMediumRisk(d, context)), 
      low: autoApproved.filter(d => this.isLowRisk(d, context)) 
    };
    const samples = { 
      high: this.sampleFromStratum(strata.high, this.samplingRates.high, 'high-risk'), 
      medium: this.sampleFromStratum(strata.medium, this.samplingRates.medium, 'medium-risk'), 
      low: this.sampleFromStratum(strata.low, this.samplingRates.low, 'low-risk') 
    };
    const allSamples = [...samples.high, ...samples.medium, ...samples.low]; 
    return { 
      method: 'stratified', 
      samples: allSamples, 
      metadata: { 
        strataSizes: { high: strata.high.length, medium: strata.medium.length, low: strata.low.length, total: autoApproved.length }, 
        sampleSizes: { high: samples.high.length, medium: samples.medium.length, low: samples.low.length, total: allSamples.length }, 
        samplingRates: this.samplingRates, 
        effectiveRate: allSamples.length / (autoApproved.length || 1), 
        confidenceLevel: this.confidenceLevel 
      } 
    };
  }
  simpleSample(decisions, context) { 
    const rate = context.samplingRate || 0.05; 
    const autoApproved = decisions.filter(d => d.decision === 'AUTO_APPROVED'); 
    const samples = autoApproved.filter(() => Math.random() < rate).map(d => ({ 
      readingId: d.readingId, 
      deviceId: d.deviceId, 
      trustScore: d.trustScore, 
      sampledForReview: true, 
      samplingReason: 'Simple random sample', 
      stratum: 'random', 
      timestamp: d.timestamp 
    }));
    return { 
      method: 'simple', 
      samples: samples, 
      metadata: { 
        totalReadings: autoApproved.length, 
        sampleSize: samples.length, 
        samplingRate: rate, 
        confidenceLevel: this.confidenceLevel 
      } 
    };
  }
  isHighRisk(decision, context) { 
    const ts = decision.trustScore; 
    const operationalDays = context.device?.operationalDays || 0; 
    const recentAnomalies = context.recentAnomalies || 0; 
    return (ts >= this.thresholds.highRisk.trustScoreMin && ts < this.thresholds.highRisk.trustScoreMax) || operationalDays < this.thresholds.highRisk.operationalDaysMax || recentAnomalies > 0;
  }
  isMediumRisk(decision, context) { 
    const ts = decision.trustScore; 
    const operationalDays = context.device?.operationalDays || 0; 
    return ts >= this.thresholds.mediumRisk.trustScoreMin && ts < this.thresholds.mediumRisk.trustScoreMax && operationalDays >= this.thresholds.mediumRisk.operationalDaysMin;
  }
  isLowRisk(decision, context) { 
    const ts = decision.trustScore; 
    const operationalDays = context.device?.operationalDays || 0; 
    const recentAnomalies = context.recentAnomalies || 0; 
    return ts >= this.thresholds.lowRisk.trustScoreMin && operationalDays >= this.thresholds.lowRisk.operationalDaysMin && recentAnomalies === 0;
  }
  sampleFromStratum(stratum, rate, label) { 
    const sampleSize = Math.ceil(stratum.length * rate); 
    const shuffled = [...stratum].sort(() => Math.random() - 0.5); 
    return shuffled.slice(0, sampleSize).map(d => ({ 
      readingId: d.readingId, 
      deviceId: d.deviceId, 
      trustScore: d.trustScore, 
      sampledForReview: true, 
      samplingReason: 'Stratified ' + label + ' sample', 
      stratum: label, 
      timestamp: d.timestamp, 
      riskFactors: this.identifyRiskFactors(d, label) 
    }));
  }
  identifyRiskFactors(decision, stratum) { 
    const factors = []; 
    if (stratum === 'high-risk') { 
      if (decision.trustScore < 0.92) factors.push('Low trust score'); 
      if (decision.deviceAge && decision.deviceAge < 180) factors.push('New device'); 
    } 
    return factors;
  }
  calculateConfidenceInterval(sampledAnomalies, sampleSize) { 
    if (sampleSize === 0) { 
      return { 
        estimate: 0, 
        lowerBound: 0, 
        upperBound: 0, 
        confidenceLevel: this.confidenceLevel, 
        interpretation: 'No samples - cannot estimate' 
      };
    }
    const p = sampledAnomalies / sampleSize; 
    const z = this.confidenceLevel === 0.99 ? 2.576 : 1.96; 
    const se = Math.sqrt((p * (1 - p)) / sampleSize); 
    const lowerBound = Math.max(0, p - z * se); 
    const upperBound = Math.min(1, p + z * se); 
    const pct = (val) => (val * 100).toFixed(2); 
    return { 
      estimate: p, 
      lowerBound: lowerBound, 
      upperBound: upperBound, 
      confidenceLevel: this.confidenceLevel, 
      sampleSize: sampleSize, 
      anomaliesFound: sampledAnomalies, 
      marginOfError: z * se, 
      interpretation: 'We are ' + (this.confidenceLevel * 100) + '% confident that the true anomaly rate is between ' + pct(lowerBound) + '% and ' + pct(upperBound) + '% (estimate: ' + pct(p) + '%)'
    };
  }
  generateSamplingReport(samplingResults, reviewResults) { 
    const metadata = samplingResults.metadata; 
    const anomaliesFound = reviewResults.anomaliesDetected || 0; 
    const totalSamples = samplingResults.samples.length; 
    const confidenceInterval = this.calculateConfidenceInterval(anomaliesFound, totalSamples); 
    return { 
      samplingMethod: samplingResults.method, 
      timestamp: new Date().toISOString(), 
      stratification: metadata.strataSizes ? { 
        highRisk: { population: metadata.strataSizes.high, sampled: metadata.sampleSizes.high, rate: metadata.samplingRates.high }, 
        mediumRisk: { population: metadata.strataSizes.medium, sampled: metadata.sampleSizes.medium, rate: metadata.samplingRates.medium }, 
        lowRisk: { population: metadata.strataSizes.low, sampled: metadata.sampleSizes.low, rate: metadata.samplingRates.low } 
      } : null, 
      summary: { 
        totalAutoApproved: metadata.strataSizes?.total || metadata.totalReadings, 
        totalSampled: totalSamples, 
        effectiveSamplingRate: metadata.effectiveRate || metadata.samplingRate, 
        anomaliesFound: anomaliesFound, 
        sampleAnomalyRate: anomaliesFound / totalSamples 
      }, 
      confidenceInterval: confidenceInterval, 
      vvbInterpretation: { 
        assurance: (this.confidenceLevel * 100) + '% confidence interval', 
        finding: confidenceInterval.interpretation, 
        recommendation: this.generateVVBRecommendation(confidenceInterval) 
      } 
    };
  }
  generateVVBRecommendation(ci) { 
    if (ci.upperBound <= 0.02) { 
      return 'Auto-approval system demonstrates high reliability (≤2% anomaly rate). Current sampling strategy is sufficient for VVB assurance.';
    } else if (ci.upperBound <= 0.05) { 
      return 'Auto-approval system shows acceptable reliability (≤5% anomaly rate). Continue monitoring with current sampling strategy.';
    } else { 
      return 'Auto-approval system shows elevated anomaly rate (>5%). Consider increasing sampling rate or reviewing trust score thresholds.';
    }
  }
}
module.exports = SmartSampler;
